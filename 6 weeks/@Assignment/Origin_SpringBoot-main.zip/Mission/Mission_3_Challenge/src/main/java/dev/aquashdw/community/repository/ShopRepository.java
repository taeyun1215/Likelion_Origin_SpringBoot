package dev.aquashdw.community.repository;

import dev.aquashdw.community.entity.ShopEntity;
import org.springframework.data.repository.CrudRepository;

public interface ShopRepository extends CrudRepository<ShopEntity, Long> {
}
