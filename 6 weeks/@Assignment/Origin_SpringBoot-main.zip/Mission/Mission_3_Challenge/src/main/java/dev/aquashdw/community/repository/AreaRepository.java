package dev.aquashdw.community.repository;

import dev.aquashdw.community.entity.AreaEntity;
import org.springframework.data.repository.CrudRepository;

public interface AreaRepository extends CrudRepository<AreaEntity, Long> {
}
